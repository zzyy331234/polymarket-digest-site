#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import os
import sqlite3
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

MIN_SIGNAL = 0.55
DB_PATH = "/Users/mac/.openclaw/workspace/polymarket/collector/polymarket_data.db"
DEFAULT_API_URL = os.environ.get("POLYMARKET_MARKETS_URL", "").strip()


# =========================
# Utils
# =========================

def parse_price(value):
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return None
        s = s.replace("$", "").replace(",", "")
        try:
            return float(s)
        except Exception:
            return None
    return None


def parse_timestamp(value):
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
        except Exception:
            return None
    return None


def parse_token_id(market: dict) -> Optional[str]:
    candidates = [
        market.get("token_id"),
        market.get("tokenId"),
        market.get("condition_id"),
        market.get("conditionId"),
        market.get("id"),
    ]
    for c in candidates:
        if c:
            return str(c)
    return None


def _safe_float(v, default=0.0):
    try:
        if v is None:
            return default
        return float(v)
    except Exception:
        return default


def normalize_market(market: dict) -> dict:
    normalized = dict(market)

    if "yes_price" not in normalized:
        if "price" in normalized:
            normalized["yes_price"] = normalized["price"]
        elif "yesProbability" in normalized:
            normalized["yes_price"] = normalized["yesProbability"]

    if "price_percentile" not in normalized:
        if "pricePercentile" in normalized:
            normalized["price_percentile"] = normalized["pricePercentile"]

    if "event_time" not in normalized:
        for key in ("end_timestamp", "close_time", "closeTime", "event_time"):
            if key in normalized:
                normalized["event_time"] = normalized[key]
                break

    normalized["event_time"] = parse_timestamp(normalized.get("event_time"))
    return normalized


def valid_market(market: dict) -> bool:
    if not isinstance(market, dict):
        return False
    if not (market.get("question") or market.get("title") or market.get("name")):
        return False
    if market.get("yes_price") is None and market.get("price") is None and market.get("yesProbability") is None:
        return False
    return True


# =========================
# Data source
# =========================

def fetch_real_markets() -> list[dict]:
    """
    直接从 SQLite 数据库读取市场数据，包含实时计算的变化率和价格分位数。
    """
    if not os.path.exists(DB_PATH):
        print(f"[fetch_real_markets] DB not found: {DB_PATH}")
        return []

    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        query = """
        WITH latest_price AS (
            SELECT 
                token_id,
                yes_price,
                no_price,
                liquidity,
                MAX(timestamp) as last_ts
            FROM price_history
            GROUP BY token_id
        ),
        first_price AS (
            SELECT 
                token_id,
                yes_price as first_yes_price,
                MIN(timestamp) as first_ts
            FROM price_history
            GROUP BY token_id
        ),
        price_stats AS (
            SELECT 
                token_id,
                MIN(yes_price) as min_yes,
                MAX(yes_price) as max_yes,
                AVG(yes_price) as avg_yes,
                COUNT(*) as cnt
            FROM price_history
            GROUP BY token_id
        )
        SELECT
            m.token_id,
            m.question,
            m.liquidity as mkt_liquidity,
            l.yes_price,
            l.no_price,
            l.liquidity as price_liquidity,
            l.last_ts,
            ROUND((l.yes_price - COALESCE(f.first_yes_price, l.yes_price)) 
                / NULLIF(f.first_yes_price, 0), 6) as one_day_change,
            ROUND((l.yes_price - COALESCE(f.first_yes_price, l.yes_price)) 
                / NULLIF(f.first_yes_price, 0), 6) as one_week_change,
            CASE 
                WHEN ps.max_yes > ps.min_yes AND ps.min_yes > 0 
                THEN ROUND((l.yes_price - ps.min_yes) / (ps.max_yes - ps.min_yes), 4)
                ELSE 0.5 
            END as price_percentile
        FROM markets m
        JOIN latest_price l ON m.token_id = l.token_id
        LEFT JOIN first_price f ON m.token_id = f.token_id
        LEFT JOIN price_stats ps ON m.token_id = ps.token_id
        WHERE 
            l.yes_price > 0 
            AND l.yes_price < 1
            AND m.liquidity > 20000
        ORDER BY m.liquidity DESC
        """

        cur.execute(query)
        rows = cur.fetchall()
        markets = []

        for row in rows:
            markets.append({
                "token_id": row["token_id"],
                "question": row["question"],
                "yes_price": row["yes_price"],
                "no_price": row["no_price"],
                "liquidity": row["mkt_liquidity"],
                "price_timestamp": row["last_ts"],
                "oneDayPriceChange": row["one_day_change"] or 0.0,
                "oneWeekPriceChange": row["one_week_change"] or 0.0,
                "rsi": 50.0,
                "price_percentile": row["price_percentile"] or 0.5,
            })

        conn.close()
        print(f"[fetch_real_markets] Loaded {len(markets)} markets from DB")
        return markets

    except Exception as e:
        print(f"[fetch_real_markets] Error: {e}")
        return []


# =========================
# MRAS Signal Logic
# =========================

def calculate_signal(market: dict) -> tuple:
    """
    Market Regime Adaptive Strategy (MRAS)

    Regime Detection (cross-validation, mutually exclusive):
        1. TREND      - 1W + 1D 同向，变化率够大
        2. MEAN_REVERT - 价格分位数极端，变化率开始回归
        3. CONTRARIAN - 共识过热 + 动能衰减
        4. NO_TRADE   - 以上都不满足，或基础过滤不过

    评分：
        - 先确认 Regime（正交条件，不互相干扰）
        - 再定方向
        - 最后算 confidence
    """

    # ── 读取字段 ──
    yes_price = _safe_float(market.get("yes_price"), 0.0)
    no_price = 1.0 - yes_price if 0 < yes_price < 1 else 0.0
    one_day = _safe_float(market.get("oneDayPriceChange"), 0.0) or 0.0
    one_week = _safe_float(market.get("oneWeekPriceChange"), 0.0) or 0.0
    liquidity = _safe_float(market.get("liquidity"), 0.0)
    rsi = _safe_float(market.get("rsi"), 50.0)
    price_pct = _safe_float(market.get("price_percentile"), 0.5)

    now_ts = datetime.now(timezone.utc).timestamp()
    event_ts = market.get("event_time")
    hours_to_event = None
    if isinstance(event_ts, (int, float)) and event_ts > 0:
        hours_to_event = (float(event_ts) - now_ts) / 3600.0

    # ── 基础过滤 ──
    if yes_price <= 0 or yes_price >= 1:
        return 0.0, None, "invalid price", _debug("no_trade")

    if liquidity < 20000:
        return 0.0, None, "liquidity too low", _debug("no_trade")

    # ── 事件时间惩罚 ──
    event_penalty = 0.0
    if hours_to_event is not None:
        if hours_to_event <= 6:
            event_penalty = 0.15
        elif hours_to_event <= 24:
            event_penalty = 0.08
        elif hours_to_event <= 48:
            event_penalty = 0.03

    # ════════════════════════════════════
    # Regime Detection（正交条件，各自独立）
    # ════════════════════════════════════

    regime = "no_trade"
    direction = None
    base_confidence = 0.0
    reasons = []
    is_contrarian = False

    # ──────────────────────────────
    # 1) TREND（趋势跟随）
    # ──────────────────────────────
    # 条件：1W + 1D 同向，变化率够大
    trend_hits = 0
    trend_conditions = []

    if abs(one_week) >= 0.05:
        trend_hits += 1
        trend_conditions.append("1W large move")
    if one_week > 0 and one_day > 0:
        trend_hits += 1
        trend_conditions.append("1D confirms 1W up")
    if one_week < 0 and one_day < 0:
        trend_hits += 1
        trend_conditions.append("1D confirms 1W down")
    if liquidity >= 50000:
        trend_hits += 1
        trend_conditions.append("liquidity confirms")

    if trend_hits >= 2:
        regime = "trend"
        if one_week > 0 or one_day > 0:
            direction = "YES"
            reasons = ["trend up"] + trend_conditions
        elif one_week < 0 or one_day < 0:
            direction = "NO"
            reasons = ["trend down"] + trend_conditions
        base_confidence = min(1.0, trend_hits / 4.0)

    # ──────────────────────────────
    # 2) MEAN REVERT（均值回归）
    # ──────────────────────────────
    # 条件：价格极端偏离（用 pct 或绝对价格双轨判断）
    # pct 在数据短时不靠谱，同时用绝对价格兜底
    elif (
        price_pct <= 0.15 or price_pct >= 0.85
        or yes_price <= 0.05 or yes_price >= 0.90
    ):
        mr_hits = 0
        mr_conditions = []

        if price_pct <= 0.15:
            mr_hits += 1
            mr_conditions.append("price at historical low")
        if price_pct >= 0.85:
            mr_hits += 1
            mr_conditions.append("price at historical high")
        if yes_price <= 0.05:
            mr_hits += 1
            mr_conditions.append("yes_price at floor")
        if yes_price >= 0.90:
            mr_hits += 1
            mr_conditions.append("yes_price at ceiling")
        if abs(one_day) >= 0.02:
            mr_hits += 1
            mr_conditions.append("1D change significant")
        if rsi <= 35 or rsi >= 65:
            mr_hits += 1
            mr_conditions.append("RSI at extreme")

        if mr_hits >= 2:
            regime = "mean_revert"
            # 低价格 + 在跌 → 超卖反弹；高价格 + 在涨 → 超买回落
            if (yes_price <= 0.05 or price_pct <= 0.15) and one_day < 0:
                direction = "YES"
                reasons = ["oversold bounce"] + mr_conditions
            elif (yes_price >= 0.90 or price_pct >= 0.85) and one_day > 0:
                direction = "NO"
                reasons = ["overbought sell"] + mr_conditions
            elif yes_price <= 0.05:
                direction = "YES"
                reasons = ["near absolute floor"] + mr_conditions
            elif yes_price >= 0.90:
                direction = "NO"
                reasons = ["near absolute ceiling"] + mr_conditions
            else:
                direction = "NO" if one_day > 0 else "YES"
                reasons = ["price extreme"] + mr_conditions
            base_confidence = min(1.0, mr_hits / 5.0)

    # ──────────────────────────────
    # 3) CONTRARIAN（反共识）
    # ──────────────────────────────
    # 条件：YES 共识极端（yes_price >= 0.50）AND 动能明显反向
    elif (
        (yes_price >= 0.50 and one_day < -0.02)
        or (yes_price >= 0.70 and one_day < 0)
    ):
        con_hits = 0
        con_conditions = []

        if yes_price >= 0.70:
            con_hits += 1
            con_conditions.append("YES consensus strong")
        elif yes_price >= 0.50:
            con_hits += 1
            con_conditions.append("YES consensus building")
        if one_day < -0.02:
            con_hits += 1
            con_conditions.append("YES momentum reversing")
        if one_week < 0:
            con_hits += 1
            con_conditions.append("1W momentum also down")
        if rsi < 55:
            con_hits += 1
            con_conditions.append("RSI not overheated")

        if con_hits >= 2:
            regime = "contrarian"
            is_contrarian = True
            direction = "NO"
            reasons = ["crowded YES fading"] + con_conditions
            base_confidence = min(1.0, con_hits / 4.0)

    # ──────────────────────────────
    # 4) NO_TRADE
    # ──────────────────────────────
    else:
        return 0.0, None, "no regime triggered", _debug("no_trade", hours_to_event=hours_to_event)

    # ════════════════════════════════════
    # Confidence + Position 计算
    # ════════════════════════════════════

    # Regime 权重（加到 base_confidence 上，不做乘法）
    regime_bonus = {"trend": 0.35, "mean_revert": 0.30, "contrarian": 0.40}.get(regime, 0.0)

    # 流动性加分
    liquidity_bonus = 0.0
    if liquidity >= 50000:
        liquidity_bonus = 0.08
        reasons.append("high liquidity")
    elif liquidity >= 100000:
        liquidity_bonus = 0.12
        reasons.append("very high liquidity")

    # RSI 加分
    rsi_bonus = 0.0
    if rsi <= 30 or rsi >= 70:
        rsi_bonus = 0.05
        reasons.append("RSI extreme")

    # 最终置信度 = base + regime权重 + 附加分 - 惩罚
    final_confidence = min(1.0, base_confidence + regime_bonus + liquidity_bonus + rsi_bonus - event_penalty)

    # 最低门槛
    min_threshold = 0.45
    if is_contrarian:
        min_threshold = 0.55

    if direction is None:
        return 0.0, None, "no direction", _debug("no_trade", hours_to_event=hours_to_event)

    if final_confidence < min_threshold:
        return 0.0, None, "below threshold", _debug(regime, confidence=final_confidence, hours_to_event=hours_to_event)

    # 仓位建议（直接用 final_confidence）
    if final_confidence >= 0.80:
        position = "large"
    elif final_confidence >= 0.65:
        position = "medium"
    else:
        position = "small"

    # Signal Score（综合分数）
    score = round(final_confidence * 100) / 100

    debug = _debug(
        regime=regime,
        score=score,
        confidence=final_confidence,
        position=position,
        is_contrarian=is_contrarian,
        yes_price=yes_price,
        no_price=no_price,
        one_day_change=one_day,
        one_week_change=one_week,
        rsi=rsi,
        price_percentile=price_pct,
        liquidity=liquidity,
        hours_to_event=hours_to_event,
        reasons=reasons,
    )

    return score, direction, "; ".join(reasons), debug


def _debug(regime, **kwargs):
    """构造 debug dict，统一格式"""
    d = {"regime": regime}
    for k, v in kwargs.items():
        d[k] = v
    # 统一保留位数
    for key in ("score", "confidence", "yes_price", "no_price", "one_day_change", "one_week_change", "liquidity"):
        if key in d and isinstance(d[key], float):
            if key in ("liquidity",):
                d[key] = round(d[key], 2)
            else:
                d[key] = round(d[key], 6)
    for key in ("rsi",):
        if key in d and isinstance(d[key], float):
            d[key] = round(d[key], 2)
    for key in ("price_percentile",):
        if key in d and isinstance(d[key], float):
            d[key] = round(d[key], 4)
    return d


def calculate_signal_legacy(market: dict) -> tuple:
    """"保留旧版 calculate_signal，命名更清晰"""
    return calculate_signal(market)
    market = normalize_market(market)

    yes_price = _safe_float(
        market.get("yes_price")
        or market.get("price")
        or market.get("yesProbability"),
        0.0
    )
    no_price = 1.0 - yes_price if 0 < yes_price < 1 else 0.0

    one_day_change = _safe_float(market.get("oneDayPriceChange"), 0.0)
    one_week_change = _safe_float(market.get("oneWeekPriceChange"), 0.0)
    liquidity = _safe_float(market.get("liquidity"), 0.0)
    rsi = _safe_float(market.get("rsi"), 50.0)
    price_percentile = _safe_float(
        market.get("price_percentile") or market.get("pricePercentile"),
        0.5
    )

    event_ts = market.get("event_time")
    now_ts = datetime.now(timezone.utc).timestamp()

    if yes_price <= 0 or yes_price >= 1:
        return 0.0, None, "invalid price", {"regime": "no_trade"}

    if liquidity < 10000:
        return 0.0, None, "liquidity too low", {"regime": "no_trade"}

    hours_to_event = None
    event_penalty = 0.0

    if isinstance(event_ts, (int, float)) and event_ts > 0:
        hours_to_event = (float(event_ts) - now_ts) / 3600.0
        if hours_to_event <= 24:
            event_penalty += 0.05
        if hours_to_event <= 12:
            event_penalty += 0.05
        if hours_to_event <= 6:
            event_penalty += 0.10

    trend_score = 0.0
    mean_revert_score = 0.0
    contrarian_score = 0.0
    confidence = 0.0
    reasons = []
    is_contrarian = False

    # trend
    if abs(one_week_change) >= 0.05:
        trend_score += 0.35
    if abs(one_day_change) >= 0.03:
        trend_score += 0.25
    if rsi >= 70 or rsi <= 30:
        trend_score += 0.15
    if liquidity >= 50000:
        trend_score += 0.10

    # mean reversion
    if price_percentile <= 0.2 or price_percentile >= 0.8:
        mean_revert_score += 0.35
    if abs(one_day_change) >= 0.03:
        mean_revert_score += 0.15
    if rsi <= 35 or rsi >= 65:
        mean_revert_score += 0.20
    if liquidity >= 30000:
        mean_revert_score += 0.10

    # contrarian
    if yes_price >= 0.75 and one_day_change < 0 and one_week_change < 0:
        contrarian_score += 0.40
    if yes_price >= 0.80 and rsi < 60:
        contrarian_score += 0.25
    if yes_price >= 0.85 and price_percentile >= 0.70:
        contrarian_score += 0.20

    regime = "no_trade"
    if contrarian_score >= 0.55:
        regime = "contrarian"
    elif trend_score >= 0.40 and trend_score >= mean_revert_score:
        regime = "trend"
    elif mean_revert_score >= 0.45:
        regime = "mean_revert"

    score = 0.0
    direction = None

    if regime == "trend":
        if one_week_change > 0 or one_day_change > 0:
            direction = "YES"
            score = trend_score
            confidence += 0.35
            reasons.append("trend up")
        elif one_week_change < 0 or one_day_change < 0:
            direction = "NO"
            score = trend_score
            confidence += 0.35
            reasons.append("trend down")

    elif regime == "mean_revert":
        if one_week_change < 0 and price_percentile <= 0.2:
            direction = "YES"
            score = mean_revert_score
            confidence += 0.30
            reasons.append("oversold mean reversion")
        elif one_week_change > 0 and price_percentile >= 0.8:
            direction = "NO"
            score = mean_revert_score
            confidence += 0.30
            reasons.append("overbought mean reversion")

    elif regime == "contrarian":
        is_contrarian = True
        if yes_price >= 0.75 and (one_day_change < 0 or one_week_change < 0):
            direction = "NO"
            score = contrarian_score
            confidence += 0.40
            reasons.append("crowded YES fading")
        elif yes_price <= 0.25 and (one_day_change > 0 or one_week_change > 0):
            direction = "YES"
            score = contrarian_score
            confidence += 0.40
            reasons.append("crowded NO fading")
    else:
        return 0.0, None, "no strong regime", {
            "regime": regime,
            "trend_score": trend_score,
            "mean_revert_score": mean_revert_score,
            "contrarian_score": contrarian_score,
            "hours_to_event": hours_to_event,
        }

    if liquidity >= 50000:
        score += 0.10
        confidence += 0.10
        reasons.append("liquidity strong")

    if rsi <= 30 or rsi >= 70:
        score += 0.05
        reasons.append("rsi extreme")

    if hours_to_event is not None:
        if hours_to_event <= 12:
            score -= 0.10
            reasons.append("event too near")
        elif hours_to_event <= 24:
            score -= 0.05
            reasons.append("event near")

    min_threshold = 0.55
    if is_contrarian:
        min_threshold = 0.65

    final_confidence = min(1.0, confidence + score / 2.0 - event_penalty)

    if direction is None:
        return 0.0, None, "no direction", {
            "regime": regime,
            "score": round(score, 4),
            "confidence": round(final_confidence, 4),
            "reasons": reasons,
            "hours_to_event": hours_to_event,
        }

    if final_confidence < min_threshold:
        return 0.0, None, "below threshold", {
            "regime": regime,
            "score": round(score, 4),
            "confidence": round(final_confidence, 4),
            "reasons": reasons,
            "hours_to_event": hours_to_event,
        }

    position = "small"
    if final_confidence >= 0.80:
        position = "large"
    elif final_confidence >= 0.68:
        position = "medium"

    debug = {
        "regime": regime,
        "score": round(score, 4),
        "confidence": round(final_confidence, 4),
        "position": position,
        "is_contrarian": is_contrarian,
        "yes_price": round(yes_price, 6),
        "no_price": round(no_price, 6),
        "one_day_change": round(one_day_change, 6),
        "one_week_change": round(one_week_change, 6),
        "rsi": round(rsi, 2),
        "price_percentile": round(price_percentile, 4),
        "liquidity": round(liquidity, 2),
        "hours_to_event": hours_to_event,
        "reasons": reasons,
    }

    return round(score, 4), direction, "; ".join(reasons), debug


# =========================
# Scanner
# =========================

def scan_opportunities(markets: list[dict]) -> list[dict]:
    results = []

    print("\n" + "=" * 90)
    print("Polymarket Scan Results")
    print("=" * 90)

    for market in markets:
        market = normalize_market(market)

        try:
            score, direction, reason, debug = calculate_signal(market)
        except Exception as e:
            name = market.get("question") or market.get("title") or market.get("name") or "unknown"
            print(f"[skip] {name}: {e}")
            continue

        if not direction or score < MIN_SIGNAL:
            continue

        name = market.get("question") or market.get("title") or market.get("name") or "unknown"
        url = market.get("url") or market.get("market_url") or ""

        result = {
            "name": name,
            "direction": direction,
            "score": round(score, 4),
            "confidence": round(debug.get("confidence", 0.0), 4),
            "position": debug.get("position", "small"),
            "regime": debug.get("regime", "-"),
            "is_contrarian": debug.get("is_contrarian", False),
            "yes_price": debug.get("yes_price"),
            "liquidity": debug.get("liquidity"),
            "hours_to_event": debug.get("hours_to_event"),
            "one_day_change": debug.get("one_day_change"),
            "one_week_change": debug.get("one_week_change"),
            "rsi": debug.get("rsi"),
            "price_percentile": debug.get("price_percentile"),
            "reason": reason,
            "reasons": debug.get("reasons", []),
            "url": url,
            "market": market,
        }
        results.append(result)

        print("-" * 90)
        print(f"Market      : {name}")
        print(f"Direction   : {direction}")
        print(f"Score       : {score:.2f}")
        print(f"Confidence  : {result['confidence']:.2f}")
        print(f"Position    : {result['position']}")
        print(f"Regime      : {result['regime']}")
        print(f"Contrarian  : {result['is_contrarian']}")
        if result["yes_price"] is not None:
            print(f"YES Price   : {result['yes_price']:.4f}")
        if result["liquidity"] is not None:
            print(f"Liquidity   : {result['liquidity']:.0f}")
        if result["hours_to_event"] is not None:
            print(f"Hours/Event : {result['hours_to_event']:.1f}")
        if result["one_day_change"] is not None:
            print(f"1D Change   : {result['one_day_change']:+.4f}")
        if result["one_week_change"] is not None:
            print(f"1W Change   : {result['one_week_change']:+.4f}")
        if result["rsi"] is not None:
            print(f"RSI         : {result['rsi']:.2f}")
        if result["price_percentile"] is not None:
            print(f"Percentile  : {result['price_percentile']:.2f}")
        print(f"Reason      : {reason}")
        if result["reasons"]:
            print(f"Signals     : {', '.join(result['reasons'])}")
        if url:
            print(f"URL         : {url}")

    print("=" * 90)
    print(f"Found {len(results)} signals")
    print("=" * 90)

    results.sort(key=lambda x: x["score"], reverse=True)
    return results


# =========================
# Main
# =========================

def main():
    markets = fetch_real_markets()

    if not markets:
        print("[main] No real markets found, using fallback test market.")
        markets = [
            {
                "question": "Will Rihanna release an album before GTA VI?",
                "yes_price": 0.55,
                "oneDayPriceChange": -0.04,
                "oneWeekPriceChange": -0.06,
                "liquidity": 58000,
                "rsi": 28,
                "price_percentile": 0.12,
                "end_timestamp": datetime.now(timezone.utc).timestamp() + 72 * 3600,
                "url": "https://polymarket.com/market/test-rihanna"
            }
        ]

    markets = [m for m in markets if valid_market(normalize_market(m))]
    if not markets:
        print("[main] No valid markets.")
        return

    scan_opportunities(markets)


if __name__ == "__main__":
    main()
