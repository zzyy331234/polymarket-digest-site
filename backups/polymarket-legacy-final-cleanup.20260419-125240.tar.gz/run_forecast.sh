#!/bin/bash
# Polymarket Forecast Scanner Cron Runner
LOG_FILE="/Users/mac/.openclaw/workspace/memory/polymarket_scan.log"
ERROR_FILE="/Users/mac/.openclaw/workspace/memory/polymarket_scan.error"

cd /Users/mac/.openclaw/workspace/polymarket
python3 polymarket_forecast.py scan >> "$LOG_FILE" 2>> "$ERROR_FILE"
echo "---EOF---" >> "$LOG_FILE"
