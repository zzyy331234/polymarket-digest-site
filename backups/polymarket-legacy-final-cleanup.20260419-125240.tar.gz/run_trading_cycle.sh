#!/bin/bash
set -e
cd /Users/mac/.openclaw/workspace/polymarket
python3 /Users/mac/.openclaw/workspace/polymarket/run_v2_scan.py
# 聪明钱监控作为辅助信号层接入，不阻断主交易链路
python3 /Users/mac/.openclaw/workspace/polymarket/smart_money_monitor.py scan || true
python3 /Users/mac/.openclaw/workspace/polymarket/alert_pipeline.py
python3 /Users/mac/.openclaw/workspace/polymarket/paper_trader.py
python3 /Users/mac/.openclaw/workspace/polymarket/review_pipeline.py
