#!/bin/bash
cd /Users/mac/.openclaw/workspace/polymarket
python3 polymarket_forecast.py scan 2>&1
